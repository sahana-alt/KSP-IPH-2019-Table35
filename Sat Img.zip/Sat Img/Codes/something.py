import cv2 
import numpy as np

red = np.array([[12.9289611 77.5046096]])
green = np.array([[12.9289611 77.5046096]])
origin = np.array([[11.9289611 77.5046096]]) #co-ordinates of origin

o_g = green - origin
o_r = red - origin 

o_red = o_r.flatten()  # convert the 2D array with 1 tuple to 1D arr
o_green = o_g.flatten()

cos = np.dot(o_green,o_red) / (np.linalg.norm(o_green) * np.linalg.norm(o_red))
ang = np.arccos(cos)

RoundedOff_angle = round(np.degrees(ang))
print (RoundedOff_angle)

#print(ang)